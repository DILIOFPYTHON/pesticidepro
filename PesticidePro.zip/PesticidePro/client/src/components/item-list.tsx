import { type Pesticide, type SelectedItem } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Minus, Trash2, Edit2 } from "lucide-react";
import { useState } from "react";

interface ItemListProps {
  pesticides: Pesticide[];
  selectedItems: SelectedItem[];
  onQuantityChange: (pesticide: Pesticide, quantity: number) => void;
  onPriceOverride?: (pesticide: Pesticide, price: number) => void;
}

export default function ItemList({
  pesticides,
  selectedItems,
  onQuantityChange,
  onPriceOverride,
}: ItemListProps) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingPrice, setEditingPrice] = useState<number | null>(null);
  const [editingQuantity, setEditingQuantity] = useState<number | null>(null);

  const handleQuantityEdit = (pesticide: Pesticide, rawValue: string) => {
    const quantity = parseInt(rawValue);
    if (!isNaN(quantity) && quantity >= 0) {
      onQuantityChange(pesticide, quantity);
    }
    setEditingId(null);
    setEditingQuantity(null);
  };

  const handlePriceEdit = (pesticide: Pesticide, rawValue: string) => {
    const price = parseFloat(rawValue);
    if (!isNaN(price) && price >= 0 && onPriceOverride) {
      onPriceOverride(pesticide, price);
    }
    setEditingId(null);
    setEditingPrice(null);
  };

  return (
    <div className="space-y-2 animate-in slide-in-from-top-2">
      {pesticides.map((pesticide) => {
        const isSaltName = pesticide.price === 0;
        const selectedItem = selectedItems.find((item) => item.id === pesticide.id);
        const quantity = selectedItem?.quantity || 0;
        const isEditing = editingId === pesticide.id;

        if (isSaltName) {
          return (
            <div 
              key={pesticide.id} 
              className="text-center font-bold text-lg text-primary py-2 border-b"
            >
              {pesticide.name}
            </div>
          );
        }

        return (
          <Card key={pesticide.id} className="overflow-hidden">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium truncate">{pesticide.name}</h3>
                  <p className="text-xs text-muted-foreground truncate">
                    {pesticide.company} • {pesticide.saltComposition}
                  </p>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {isEditing && editingPrice !== null ? (
                    <Input
                      type="number"
                      className="w-20 h-8"
                      value={editingPrice}
                      onChange={(e) => setEditingPrice(parseFloat(e.target.value))}
                      onBlur={(e) => handlePriceEdit(pesticide, e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handlePriceEdit(pesticide, e.currentTarget.value)}
                      autoFocus
                    />
                  ) : (
                    <div className="flex items-center gap-1" onClick={() => {
                      setEditingId(pesticide.id);
                      setEditingPrice(Number(pesticide.price));
                    }}>
                      <span className="text-sm font-medium">₹{pesticide.price}</span>
                      <Edit2 className="h-3 w-3 text-muted-foreground" />
                    </div>
                  )}

                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => onQuantityChange(pesticide, quantity - 1)}
                      disabled={quantity === 0}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>

                    {isEditing && editingQuantity !== null ? (
                      <Input
                        type="number"
                        className="w-16 h-8"
                        value={editingQuantity}
                        onChange={(e) => setEditingQuantity(parseInt(e.target.value))}
                        onBlur={(e) => handleQuantityEdit(pesticide, e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleQuantityEdit(pesticide, e.currentTarget.value)}
                        autoFocus
                      />
                    ) : (
                      <span 
                        className="w-8 text-center text-sm cursor-pointer" 
                        onClick={() => {
                          setEditingId(pesticide.id);
                          setEditingQuantity(quantity);
                        }}
                      >
                        {quantity}
                      </span>
                    )}

                    <Button
                      variant="outline"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => onQuantityChange(pesticide, quantity + 1)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>

                    {quantity > 0 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => onQuantityChange(pesticide, 0)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}