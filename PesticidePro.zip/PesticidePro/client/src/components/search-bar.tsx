import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ChevronDown, ChevronUp } from "lucide-react";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  showList: boolean;
  onToggleList: () => void;
}

export default function SearchBar({
  value,
  onChange,
  showList,
  onToggleList,
}: SearchBarProps) {
  return (
    <div className="flex gap-2">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          className="pl-9"
          placeholder="Search Pesticide..."
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
      <Button
        variant="outline"
        size="icon"
        onClick={onToggleList}
        className="shrink-0"
      >
        {showList ? <ChevronUp /> : <ChevronDown />}
      </Button>
    </div>
  );
}
