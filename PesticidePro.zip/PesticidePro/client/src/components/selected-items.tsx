import { type Pesticide, type SelectedItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Minus, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface SelectedItemsProps {
  selectedItems: SelectedItem[];
  pesticides: Pesticide[];
  onQuantityChange: (pesticide: Pesticide, quantity: number) => void;
  onClearCart: () => void;
}

export default function SelectedItems({
  selectedItems,
  pesticides,
  onQuantityChange,
  onClearCart,
}: SelectedItemsProps) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingQuantity, setEditingQuantity] = useState<number | null>(null);
  const [showAllItems, setShowAllItems] = useState(false);

  if (selectedItems.length === 0) {
    return null;
  }

  const handleQuantityEdit = (pesticide: Pesticide, rawValue: string) => {
    const quantity = parseInt(rawValue);
    if (!isNaN(quantity) && quantity >= 0) {
      onQuantityChange(pesticide, quantity);
    }
    setEditingId(null);
    setEditingQuantity(null);
  };

  const visibleItems = showAllItems ? selectedItems : selectedItems.slice(0, 3);
  const hasHiddenItems = selectedItems.length > 3;

  return (
    <div className="space-y-2">
      <Button 
        variant="destructive" 
        size="sm"
        onClick={onClearCart}
        className="flex items-center gap-2 mb-2"
      >
        <Trash2 className="h-4 w-4" />
        Clear All
      </Button>
      <div className="space-y-2">
        {visibleItems.map((item, index) => {
          const pesticide = pesticides.find((p) => p.id === item.id);
          if (!pesticide) return null;

          return (
            <div
              key={item.id}
              className="flex items-center justify-between animate-in slide-in-from-top-2"
              style={{
                animationDelay: `${index * 100}ms`,
              }}
            >
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm text-muted-foreground">{index + 1})</span>
                <span className="font-medium truncate">{pesticide.name}</span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => onQuantityChange(pesticide, item.quantity - 1)}
                  >
                    <Minus className="h-3 w-3" />
                  </Button>

                  {editingId === item.id && editingQuantity !== null ? (
                    <Input
                      type="number"
                      className="w-14 h-6"
                      value={editingQuantity}
                      onChange={(e) => setEditingQuantity(parseInt(e.target.value))}
                      onBlur={(e) => handleQuantityEdit(pesticide, e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleQuantityEdit(pesticide, e.currentTarget.value)}
                      autoFocus
                    />
                  ) : (
                    <span 
                      className="w-6 text-center text-sm cursor-pointer"
                      onClick={() => {
                        setEditingId(item.id);
                        setEditingQuantity(item.quantity);
                      }}
                    >
                      {item.quantity}
                    </span>
                  )}

                  <Button
                    variant="outline"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => onQuantityChange(pesticide, item.quantity + 1)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-right text-sm">
                  ₹{item.total.toFixed(2)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-destructive hover:text-destructive"
                  onClick={() => onQuantityChange(pesticide, 0)}
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          );
        })}

        {hasHiddenItems && (
          <>
            {!showAllItems && (
              <div className="relative h-12 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
                <div className="opacity-50">
                  {selectedItems[3] && pesticides.find(p => p.id === selectedItems[3].id)?.name}
                </div>
              </div>
            )}
            <Button
              variant="ghost"
              className="w-full"
              onClick={() => setShowAllItems(!showAllItems)}
            >
              {showAllItems ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}