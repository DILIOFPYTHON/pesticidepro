// Google Sheets API configuration and helper functions
import { google } from 'googleapis';
import type { Pesticide } from '@shared/schema';

// Cache configuration
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
let cachedData: Pesticide[] | null = null;
let lastFetchTime = 0;

// Helper function to check if cache is valid
const isCacheValid = () => {
  return cachedData && (Date.now() - lastFetchTime) < CACHE_DURATION;
};

// Helper function to parse row data into Pesticide object
const parseRow = (row: any[], index: number): Pesticide => {
  return {
    id: index + 1,
    name: row[0] || '',
    price: parseFloat(row[1]) || 0,
    saltComposition: row[2] || '',
    company: row[3] || '',
    lastUpdated: new Date()
  };
};

// Main function to fetch data from Google Sheets
export async function fetchPesticideData(): Promise<Pesticide[]> {
  // Return cached data if valid
  if (isCacheValid() && cachedData) {
    return cachedData;
  }

  try {
    // Initialize Google Sheets API
    const auth = new google.auth.GoogleAuth({
      keyFile: process.env.GOOGLE_SHEETS_KEY_FILE,
      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']
    });

    const sheets = google.sheets({ version: 'v4', auth });
    
    // Get spreadsheet ID from environment variable
    const spreadsheetId = process.env.SPREADSHEET_ID || '';
    if (!spreadsheetId) {
      throw new Error('SPREADSHEET_ID environment variable is not set');
    }

    // Fetch data from the sheet
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: 'Sheet1!A2:D', // Assuming data starts from A2
    });

    const rows = response.data.values || [];

    // Transform the data
    const pesticides = rows.map((row, index) => parseRow(row, index));

    // Update cache
    cachedData = pesticides;
    lastFetchTime = Date.now();

    return pesticides;
  } catch (error) {
    console.error('Error fetching data from Google Sheets:', error);
    
    // Return cached data if available, otherwise throw
    if (cachedData) {
      console.log('Returning cached data due to fetch error');
      return cachedData;
    }
    
    throw new Error('Failed to fetch pesticide data');
  }
}

// Function to clear cache (useful for testing or forced refresh)
export function clearCache() {
  cachedData = null;
  lastFetchTime = 0;
}

// Helper function to validate spreadsheet format
export async function validateSpreadsheetFormat(): Promise<boolean> {
  try {
    const pesticides = await fetchPesticideData();
    
    // Basic validation of required fields
    return pesticides.every(pesticide => 
      typeof pesticide.name === 'string' &&
      typeof pesticide.price === 'number' &&
      !isNaN(pesticide.price) &&
      pesticide.price > 0
    );
  } catch (error) {
    console.error('Spreadsheet validation failed:', error);
    return false;
  }
}

// Function to get last update time
export function getLastUpdateTime(): Date | null {
  return lastFetchTime ? new Date(lastFetchTime) : null;
}
