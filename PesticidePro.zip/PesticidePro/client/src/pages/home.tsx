import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Pesticide, type SelectedItem } from "@shared/schema";
import SearchBar from "@/components/search-bar";
import ItemList from "@/components/item-list";
import SelectedItems from "@/components/selected-items";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [search, setSearch] = useState("");
  const [showList, setShowList] = useState(true);
  const [selectedItems, setSelectedItems] = useState<SelectedItem[]>([]);
  const [priceOverrides, setPriceOverrides] = useState<Record<number, number>>({});

  const { data: pesticides, isLoading } = useQuery<Pesticide[]>({
    queryKey: ["/api/pesticides"],
  });

  const filteredPesticides = pesticides?.filter((item) =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleQuantityChange = (
    pesticide: Pesticide,
    newQuantity: number
  ) => {
    setSelectedItems((prev) => {
      const existing = prev.find((item) => item.id === pesticide.id);
      if (newQuantity <= 0) {
        return prev.filter((item) => item.id !== pesticide.id);
      }
      if (existing) {
        return prev.map((item) =>
          item.id === pesticide.id
            ? { 
                ...item, 
                quantity: newQuantity, 
                total: newQuantity * (priceOverrides[pesticide.id] || Number(pesticide.price)) 
              }
            : item
        );
      }
      return [
        ...prev,
        { 
          id: pesticide.id, 
          quantity: newQuantity, 
          total: newQuantity * (priceOverrides[pesticide.id] || Number(pesticide.price))
        },
      ];
    });
  };

  const handlePriceOverride = (pesticide: Pesticide, newPrice: number) => {
    setPriceOverrides(prev => ({ ...prev, [pesticide.id]: newPrice }));
    // Update total for this item if it's selected
    setSelectedItems(prev => prev.map(item => 
      item.id === pesticide.id
        ? { ...item, total: item.quantity * newPrice }
        : item
    ));
  };

  const handleClearCart = () => {
    setSelectedItems([]);
    setPriceOverrides({});
  };

  const grandTotal = selectedItems.reduce((sum, item) => sum + item.total, 0);

  if (isLoading) {
    return (
      <div className="container max-w-md mx-auto p-4 space-y-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  return (
    <div className="container max-w-md mx-auto p-4 space-y-4">
      {selectedItems.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <SelectedItems
              selectedItems={selectedItems}
              pesticides={pesticides?.map(p => ({
                ...p,
                price: priceOverrides[p.id] || p.price
              })) || []}
              onQuantityChange={handleQuantityChange}
              onClearCart={handleClearCart}
            />
            <div className="text-xl font-bold border-t mt-4 pt-4">
              Total: ₹{grandTotal.toFixed(2)}
            </div>
          </CardContent>
        </Card>
      )}

      <SearchBar
        value={search}
        onChange={setSearch}
        showList={showList}
        onToggleList={() => setShowList(!showList)}
      />

      {(showList || search) && (
        <ItemList
          pesticides={filteredPesticides || []}
          selectedItems={selectedItems}
          onQuantityChange={handleQuantityChange}
          onPriceOverride={handlePriceOverride}
        />
      )}
    </div>
  );
}