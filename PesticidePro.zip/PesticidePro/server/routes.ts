import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express) {
  app.get("/api/pesticides", async (_req, res) => {
    try {
      const pesticides = await storage.getAllPesticides();
      res.json(pesticides);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch pesticides" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
