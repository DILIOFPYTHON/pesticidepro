import { Pesticide, type InsertPesticide } from "@shared/schema";
import { google } from "googleapis";
import type { GoogleAuth } from "google-auth-library";
import path from "path";

export interface IStorage {
  getAllPesticides(): Promise<Pesticide[]>;
  updatePesticides(pesticides: Pesticide[]): Promise<void>;
}

export class MemStorage implements IStorage {
  private pesticides: Pesticide[];
  private lastFetch: number;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  constructor() {
    this.pesticides = [];
    this.lastFetch = 0;
  }

  async getAllPesticides(): Promise<Pesticide[]> {
    const now = Date.now();
    if (now - this.lastFetch > this.CACHE_DURATION) {
      await this.fetchFromGoogleSheets();
      this.lastFetch = now;
    }
    return this.pesticides;
  }

  async updatePesticides(pesticides: Pesticide[]): Promise<void> {
    this.pesticides = pesticides;
  }

  private async fetchFromGoogleSheets() {
    try {
      const keyFilePath = path.resolve("attached_assets", "pesticidecalculator-f5e7b4ef098a.json");
      const auth = new google.auth.GoogleAuth({
        keyFile: keyFilePath,
        scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
      });

      const sheets = google.sheets({ version: 'v4', auth });

      if (!process.env.SPREADSHEET_ID) {
        throw new Error('SPREADSHEET_ID environment variable is not set');
      }

      console.log('Fetching from spreadsheet:', process.env.SPREADSHEET_ID);

      // First, let's get the spreadsheet info to verify sheets
      const spreadsheet = await sheets.spreadsheets.get({
        spreadsheetId: process.env.SPREADSHEET_ID,
      });

      console.log('Available sheets:', spreadsheet.data.sheets?.map(sheet => sheet.properties?.title));

      // Now fetch the data
      const response = await sheets.spreadsheets.values.get({
        spreadsheetId: process.env.SPREADSHEET_ID,
        range: "Pesticides!A2:D", // Changed from Sheet1 to Pesticides
      });

      const rows = response.data.values || [];
      console.log('Fetched rows:', rows.length);

      this.pesticides = rows.map((row: string[], index: number) => ({
        id: index + 1,
        name: row[0] || '',
        price: row[1] ? parseFloat(row[1]) : 0,
        saltComposition: row[2] || '',
        company: row[3] || '',
        lastUpdated: new Date(),
      }));

      console.log('Processed pesticides:', this.pesticides.length);
    } catch (error) {
      console.error('Error fetching from Google Sheets:', error);
      // Keep using cached data if fetch fails
    }
  }
}

export const storage = new MemStorage();