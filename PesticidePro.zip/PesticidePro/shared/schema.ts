import { pgTable, text, serial, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const pesticides = pgTable("pesticides", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  saltComposition: text("salt_composition"),
  company: text("company"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertPesticideSchema = createInsertSchema(pesticides, {
  price: z.number().positive(),
}).pick({
  name: true,
  price: true,
  saltComposition: true,
  company: true,
});

export type InsertPesticide = z.infer<typeof insertPesticideSchema>;
export type Pesticide = typeof pesticides.$inferSelect;

export interface SelectedItem {
  id: number;
  quantity: number;
  total: number;
}